package com.example.stepplugin1;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;

//unity 와 연동
import com.unity3d.player.UnityPlayer;

public class StepCounterPlugin1 implements SensorEventListener {

    private static StepCounterPlugin1 instance;

    private SensorManager sensorManager;
    private Sensor stepSensor;
    private LocationManager locationManager;

    private int initialStep = -1;
    private int currentStep = 0;

    private double schoolLat = 35.1533;
    private double schoolLon = 128.0994;
    private float validRadiusMeters = 1000f;

    private boolean insideCampus = false;

    private StepCounterPlugin1(Context context) {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
    }

    public static StepCounterPlugin1 getInstance(Context context) {
        if (instance == null) {
            instance = new StepCounterPlugin1(context);
        }
        return instance;
    }

    public void startTracking() {
        if (stepSensor != null) {
            sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI);
        }
    }

    public void stopTracking() {
        sensorManager.unregisterListener(this);
    }

    public int getStepCount() {
        if (insideCampus) {
            return currentStep;
        } else {
            return 0;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!insideCampus) {
            if (checkInCampus()) {
                insideCampus = true;
                initialStep = (int) event.values[0];
            } else {
                return; // 캠퍼스 밖이면 무시
            }
        }

        int sensorValue = (int) event.values[0];
        currentStep = sensorValue - initialStep;

        // Unity에 걸음 수 전달
        UnityPlayer.UnitySendMessage("StepManager", "OnStepChanged", String.valueOf(currentStep));
    }

    private boolean checkInCampus() {
        try {
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location == null) return false;

            float[] result = new float[1];
            Location.distanceBetween(
                    location.getLatitude(), location.getLongitude(),
                    schoolLat, schoolLon,
                    result
            );
            return result[0] <= validRadiusMeters;
        } catch (SecurityException e) {
            return false;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}